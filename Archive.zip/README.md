# shiny-counter-extension
A chrome extension with a custom keybind for count while browsing
